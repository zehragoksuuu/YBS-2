package ODEV;

public class SORU3 {
	Node head = null;
	Node tail = null;
	
	
	void arayaekle(int indis, Node yeni ) {
		if (head==null) {
			head=yeni;
			tail=yeni;
		}
		else if (head!=null && indis==0) {
			yeni.next=head;
			head.prev=yeni;
			head=yeni;
		}
		else {
			int i=0;
			Node temp = head;
			while (temp!=null) {
				temp=temp.next;
				i++;
			}
			if (indis>i) {
				tail.next=yeni;
				yeni.prev=tail;
				tail=yeni;
			}
			else {
				int j = 0;
				while (i!=indis) {
					temp=temp.next;
					j++;
				}
				yeni.prev=temp.prev;
				temp.prev.next=yeni;
				yeni.next=temp;
				temp.prev=yeni;
				
				
				
			}
			
		}
		
		
		
		
		
	}
	
	

	public static void main(String[] args) {

		Node n = new Node(83);
		SORU3 s3 = new SORU3();
		s3.arayaekle(2, n);
		
		
	}
	
	
	

}
