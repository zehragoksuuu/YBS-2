package ODEV;

public class SORU1 {
	Node head = null;
	Node tail = null;

	void ekle(Node yeni) {
		if (head == null) {
			head = yeni;
			tail = yeni;
			yeni.next = null;
		} else {
			tail.next = yeni;
			yeni.next = null;
			tail = yeni;
		}

	}

	void yazdır() {
		if (head == null) {
			System.out.println("liste boş");
		} else {
			Node temp = head;
			while (temp != null) {
				System.out.println(temp.isim + " " + temp.not);
				temp = temp.next;
			}
		}
	}

	public static void main(String[] args) {
		SORU1 s = new SORU1();

		Node o1 = new Node("Ali", 88);
		s.ekle(o1);
		Node o2 = new Node("Veli", 108);
		s.ekle(o2);
		Node o3 = new Node("Ayşe", 98);
		s.ekle(o3);
		s.yazdır();
		Node o4 = new Node("Fatma", 30);
		s.ekle(o4);
		s.basarili(o1, o2, o3, o4);

	}

	void basarili(Node y1, Node y2, Node y3, Node y4) {
		
		if (y1.not>y2.not && y3.not>y4.not && y1.not>y3.not) {
			System.out.println("EN BAŞARILI ÖĞRENCİ = "+y1.isim);
		}
		else if (y1.not>y2.not && y3.not>y4.not && y3.not>y1.not) {
			System.out.println("EN BAŞARILI ÖĞRENCİ = "+y3.isim);

		}
		else if ( y2.not>y1.not && y3.not>y4.not && y2.not>y3.not) {
			System.out.println("EN BAŞARILI ÖĞRENCİ = "+y2.isim);

		}
		else {
			System.out.println("EN BAŞARILI ÖĞRENCİ = "+y4.isim);

		}
		
		
	}
}
