package ODEV;

public class Node {
	
	Node next;
	Node prev;
	String isim;
	double not;
	double boy;
	int kilo;
	int sayı;
	
	public Node(String isim, double not) {

		this.isim=isim;
		this.not=not;
	
	}
	public Node(String isim, int kilo, double boy ) {
		
		this.isim=isim;
		this.boy=boy;
		this.kilo=kilo;
			
	}
	public Node(int sayı) {
	this.sayı=sayı;
	
	}
	

}
