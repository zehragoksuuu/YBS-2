package ODEV;

import Sınıf1.asalSayı;

public class SORU2 {
	Node head = null;
	Node tail = null;
	
	void ekle(Node yeni) {
		if(head==null) {
			head=yeni;
			tail=yeni;
			tail.next=null;
		}
		else {
			tail.next=yeni;
			tail=yeni;
		}
	}
	
	void yazdır() {
		if (head==null) {
			System.out.println("liste boş");
		}
		else {
			Node temp=head;
			while (temp!=null) {
				System.out.println(temp.isim+" "+temp.kilo+" "+temp.boy);
				temp=temp.next;
			}
		}
	}
	void sil(int indeks) {
		if(head==null) {
			System.out.println("liste boş");
		}
		else if (head.next==null && indeks==0) {
			
		    head=null;
		    tail=null;
		    System.out.println("listede kalan son eleman silindi");
		}
		else if (head.next!=null && indeks==0) {
			head=head.next;
			System.out.println("baştaki eleman silindi");
		}
		else {
			int i = 0;
			Node temp = head;
			Node temp2 = head;
			while (temp!=null) {
				temp2 = temp;
				temp=temp.next;
				i++;
			}
			 if(i==indeks) {
				 temp2.next=null;
				 tail=temp2;
				 System.out.println("listedeki son eleman silindi");
			 }
			 else {
				temp=head;
				temp2=head;
				int j=0;
				while (j!=indeks) {  //3 
					temp2=temp;
					temp=temp.next;
					j++;
				}
				temp2.next=temp.next;
				temp=null;
				System.out.println("aradaki eleman silindi");
				 
			}
			
		}
	}
	
	

	public static void main(String[] args) {
		SORU2 a = new SORU2();

		Node s1 = new Node("Ayşe", 45, 1.70);
		Node s2 = new Node("Ali", 78, 1.90);
		Node s3 = new Node("Ahmet", 56, 1.50);
		Node s4 = new Node("Veli", 65, 1.69);
		Node s5 = new Node("Kemal", 59, 1.63);
		a.ekle(s1);
		a.ekle(s2);
		a.ekle(s3);
		a.ekle(s4);
		a.ekle(s5);
		a.yazdır();
		a.sil(3);
		a.yazdır();
		
		if (hesapla(s1)=="obez") {
			System.out.println(s1.isim+" obez");
			
		}
		else if (hesapla(s2)=="obez") {
			System.out.println(s2.isim+" obez");

		}
		else if (hesapla(s3)=="obez") {
			System.out.println(s3.isim+" obez");

		}
		else if (hesapla(s4)=="obez") {
			System.out.println(s4.isim+" obez");

		}
		else if (hesapla(s5)=="obez") {
			System.out.println(s5.isim+" obez");

		}
		else {
			System.out.println("obez yok");
		}
		
	
		
	}
     public static String hesapla(Node eleman){
		
    	 double vki = (eleman.kilo)/(eleman.boy*eleman.boy);
    	 
    	 if (vki<18.5) {
			System.out.println("DÜŞÜK KİLOLU");
			return "düşük";
		}
    	 else if (vki<25) {
 			System.out.println("NORMAL KİLOLU");
 			return "normal";
		}
    	 else if (vki<30) {
 			System.out.println("FAZLA KİLOLU");
 			return "fazla";
		}
    	 else {
 			System.out.println("OBEZ");
 			return "obez";
		}
		
		}
}
