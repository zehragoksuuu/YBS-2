package ODEV;

public class SORU4 {
	
	Node head = null;
	Node tail = null;
	void basaekle(Node yeni) {
		if(head==null) {
			head=yeni;
			tail=yeni;
		}
		else {
			head.prev=yeni;
			yeni.next=head;
			head=yeni;
		}
	}
	void sonaekle(Node yeni) {
		if(head==null) {
			head=yeni;
			tail=yeni;
		}
		else if (head.next==null) {
			head.next=yeni;
			yeni.prev=head;
			tail=yeni;
		}
		else {
			tail.next=yeni;
			yeni.prev=tail;
			tail=yeni;
			
		}
	}
	void yazdır() {
		if (head == null) {
			System.out.println("liste boş");
		} else {
			Node temp = head;
			while (temp != null) {
				System.out.println(temp.sayı);
				temp = temp.next;
			}
		}
		System.out.println();
	}
	void sil() {
		
		if (head==null) {
			System.out.println("silinecek eleman yok");
		}
		else {
			Node temp = head;
			Node temp2 = head;
			while (temp.next!=null) {
				temp2=temp;
				temp=temp.next;
			}

			temp2.next.prev=temp2.prev;
			temp2.prev.next=temp2.next;
			
			
			
			

		}
	}
	

	public static void main(String[] args) {

		Node eleman1 = new Node(98);
		Node eleman2 = new Node(12);
		Node eleman3 = new Node(294);
		Node eleman4 = new Node(53);
		SORU4 s = new SORU4();
		s.sonaekle(eleman1);
		s.sonaekle(eleman2);
		s.sonaekle(eleman3);
		s.sonaekle(eleman4);
		s.yazdır();
		s.sil();
		s.yazdır();
		
		
		

		
		
		
	}

}
