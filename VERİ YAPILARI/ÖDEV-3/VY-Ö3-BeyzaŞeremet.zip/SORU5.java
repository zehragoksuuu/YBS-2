package ODEV;

import java.util.Iterator;

public class SORU5 {
	Node head = null;
	Node tail = null;

	void ekle(Node yeni) {
		if (head == null) {
			head = yeni;
			tail = yeni;
			tail.next = null;
		} else {
			tail.next = yeni;
			tail = yeni;
		}
	}

	void yazdır() {
		if (head == null) {
			System.out.println("liste boş");
		} else {
			Node temp = head;
			while (temp != null) {
				System.out.println(temp.sayı);
				temp = temp.next;
			}
		}
	}
	void terstenyaz() {
		if (head == null) {
			System.out.println("liste boş");
		}
		else {
			
			Node temp= head;
			
			int dizi[] = new int[4];
			int i=0;
			while (temp!=null) {
				dizi[i]=temp.sayı;
				temp=temp.next;
				i++;
			}
			
			int j = dizi.length-1;
			while (j>=0) {
				System.out.println(dizi[j]);
				j--;
			}
			 
		
		}
		
		
	}

	public static void main(String[] args) {

		SORU5 s5 = new SORU5();
		Node eleman1 = new Node(33);
		s5.ekle(eleman1);
		Node eleman2 = new Node(345);
		Node eleman3 = new Node(95);
		Node eleman4 = new Node(675);

		s5.ekle(eleman2);
		s5.ekle(eleman3);
		s5.ekle(eleman4);
		s5.yazdır();
		s5.terstenyaz();

	}

}
